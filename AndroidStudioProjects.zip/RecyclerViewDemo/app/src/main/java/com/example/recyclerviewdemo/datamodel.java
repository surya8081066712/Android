package com.example.recyclerviewdemo;

import android.net.Uri;

public class datamodel {

    String FacultyName;
    String SubjectName;
    String CollegeName;
    String Image;

    public datamodel() {
    }

    public datamodel(String facultyName, String subjectName, String collegeName, String image) {
        FacultyName = facultyName;
        SubjectName = subjectName;
        CollegeName = collegeName;
        Image = image;
    }

    public String getFacultyName() {
        return FacultyName;
    }

    public void setFacultyName(String facultyName) {
        FacultyName = facultyName;
    }

    public String getSubjectName() {
        return SubjectName;
    }

    public void setSubjectName(String subjectName) {
        SubjectName = subjectName;
    }

    public String getCollegeName() {
        return CollegeName;
    }

    public void setCollegeName(String collegeName) {
        CollegeName = collegeName;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }
}
