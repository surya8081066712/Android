package com.example.recyclerviewdemo.network;
// This class created to get the required Json response
public class ResponeObj
{
    Integer id;
    String name;

    public String[] getSubjects() {
        return subjects;
    }

    public String[] getQualification() {
        return qualification;
    }



    String[] subjects;
    String[] qualification;
    String profileImage;

    public Integer getId() {
        return id;
    }



    public String getName() {
        return name;
    }







    public String getProfileImage() {
        return profileImage;
    }


}
