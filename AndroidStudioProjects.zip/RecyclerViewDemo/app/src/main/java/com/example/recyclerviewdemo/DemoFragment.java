package com.example.recyclerviewdemo;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.recyclerviewdemo.network.JsonRequest;
import com.example.recyclerviewdemo.network.ResponeObj;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class DemoFragment extends Fragment {


  RecyclerView recyclerView;
    ArrayList<datamodel> dataholder;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

    // create the object for retrofit networking library
       Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(" https://my-json-server.typicode.com/easygautam/")
                .addConverterFactory(GsonConverterFactory.create()).build();
        // creating the object of jsonRequest using predefined retrofit
        JsonRequest jsonRequest=retrofit.create(JsonRequest.class);
        //  To call the Get request
        Call<List<ResponeObj>> call=jsonRequest.listRepos();


        // Inflate the layout for this fragment
        //fetching the recycler view through below code
       View view=inflater.inflate(R.layout.fragment_demo,container,false);
       recyclerView=view.findViewById(R.id.recyclrview);
       recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

       //Sending Get request
        call.enqueue(new Callback<List<ResponeObj>>() {
            @Override
            public void onResponse(@NonNull Call<List<ResponeObj>> call, @NonNull Response<List<ResponeObj>> response) {
                if(!response.isSuccessful())
                    Log.d("res", "onResponse: "+response.code());

                List<ResponeObj> obj=response.body();
                assert obj != null;
                Log.d("size", "onResponse: "+obj.size());
                // here dataholder is an arraylist which will hold objects of datamodel type
                dataholder=new ArrayList<>();
                for(ResponeObj res:obj)
                {
                    datamodel obj1=new datamodel(res.getName(),res.getSubjects()[0],res.getQualification().length==1?res.getQualification()[0]:res.getQualification()[0]+"\n"+res.getQualification()[1],res.getProfileImage());
                    dataholder.add(obj1);
                }




                recyclerView.setAdapter(new Adapter(dataholder,getContext()));


            }

            @Override
            public void onFailure(@NonNull Call<List<ResponeObj>> call, @NonNull Throwable t) {
                Log.d("failure", "onFailure: "+t.getMessage());
            }
        });


       //initializing the dataholder
       return view;
    }
}