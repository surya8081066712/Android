package com.example.recyclerviewdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
//import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    public Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // referencing the show button
        btn=(Button)findViewById(R.id.show);


        //when button is clicked.
        btn.setOnClickListener(view -> {
            Intent in=new Intent(MainActivity.this,MainActivity2.class);// moving to first activity to second activity
            startActivity(in);
        });
    }

}