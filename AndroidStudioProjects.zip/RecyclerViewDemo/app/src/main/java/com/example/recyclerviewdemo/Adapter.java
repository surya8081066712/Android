package com.example.recyclerviewdemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    ArrayList<datamodel> dataholder;
    Context context;

    public Adapter(ArrayList<datamodel> dataholder, Context context) {
        this.dataholder = dataholder;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
      holder.t1.setText(dataholder.get(position).getFacultyName());
      holder.t2.setText(dataholder.get(position).getSubjectName());
      holder.t3.setText(dataholder.get(position).getCollegeName());
        Picasso.with(context)
                .load(dataholder.get(position).getImage())
                .resize(250, 300)
                .into(holder.iv);


    }

    @Override
    public int getItemCount() {
        return dataholder.size();
    }
// viewholder is the class which referencing the cardview.xml
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView t1,t2,t3;
        ImageView iv;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            t1=itemView.findViewById(R.id.facultyName);
            t2=itemView.findViewById(R.id.subjectName);
            t3=itemView.findViewById(R.id.collegeName);
            iv=(itemView).findViewById(R.id.facultyImage);

        }
    }
}
