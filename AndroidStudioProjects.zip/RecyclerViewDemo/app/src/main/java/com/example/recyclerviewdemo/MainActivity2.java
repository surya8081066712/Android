package com.example.recyclerviewdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.ArrayAdapter;

import com.example.recyclerviewdemo.databinding.ActivityMain2Binding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        // for back button setDisplayHomeAsUpEnabled used here
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportyFragmentManager is used here to replace the mainActivity2 with DemoFrament
        getSupportFragmentManager().beginTransaction().replace(R.id.maincontainer,new DemoFragment()).commit();


    }


}