package com.example.recyclerviewdemo.network;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface JsonRequest {

//binding get request end point URL
@GET("data/users")
Call<List<ResponeObj>> listRepos();
}
